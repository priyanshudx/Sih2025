"use client"

import { useState } from "react"
import { AppProvider } from "./context/AppContext"
import Layout from "./components/Layout"
import Dashboard from "./pages/Dashboard"
import Projects from "./pages/Projects"
import Credits from "./pages/Credits"
import Settings from "./pages/Settings"

export type PageType = "dashboard" | "projects" | "credits" | "settings"

function App() {
  const [currentPage, setCurrentPage] = useState<PageType>("dashboard")

  const renderPage = () => {
    switch (currentPage) {
      case "dashboard":
        return <Dashboard setCurrentPage={setCurrentPage} />
      case "projects":
        return <Projects />
      case "credits":
        return <Credits />
      case "settings":
        return <Settings />
      default:
        return <Dashboard setCurrentPage={setCurrentPage} />
    }
  }

  return (
    <AppProvider>
      <Layout currentPage={currentPage} setCurrentPage={setCurrentPage}>
        {renderPage()}
      </Layout>
    </AppProvider>
  )
}

export default App
